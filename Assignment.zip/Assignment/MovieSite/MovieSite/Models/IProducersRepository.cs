﻿using MovieSite.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieSite.Models
{
    public interface IProducersRepository
    {

        IEnumerable<Producers> ListProducers();
        IEnumerable<Producers> getproducername();
        bool AddProducer(Producers producerdata);
        //Movies Add(Movies newmovie);
        //Movies Edit(Movies moviechange);
        //Movies Delete(int id);

    }
}
