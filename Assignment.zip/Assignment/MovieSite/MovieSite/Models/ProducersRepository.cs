﻿using MovieSite.ViewModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using static MovieSite.Models.Producers;

namespace MovieSite.Models
{
    public class ProducersRepository : IProducersRepository
    {
        private readonly string connectionstring = String.Empty;
        private readonly SqlConnection conn = null;
        private List<Producers> _producers;
        

        public ProducersRepository()
        {
            _producers = new List<Producers>();
            connectionstring = "Server=tcp:moviesiteserver.database.windows.net,1433;Initial Catalog=MoviesSiteDB;Persist Security Info=False;User ID=moviesiteserver;Password=Moviesite@123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
            conn = new SqlConnection(connectionstring);

        }

        public IEnumerable<Producers> getproducername()
        {
            SqlCommand cmd = new SqlCommand("getallproducerdetailsprocedure", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            conn.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    Producers producer = new Producers();
                    producer.Id = Convert.ToInt32(rdr.GetValue(0).ToString());
                    producer.Name = rdr.GetValue(1).ToString();
                    producer.Sex = (ProducerSex)Enum.Parse(typeof(ProducerSex), rdr.GetValue(2).ToString());
                    producer.DOB = Convert.ToDateTime(rdr.GetValue(3).ToString());
                    producer.Bio = rdr.GetValue(4).ToString();

                    _producers.Add(producer);
                }
            }
            conn.Close();
            return _producers;
        }

        public IEnumerable<Producers> ListProducers()
        {
            SqlCommand cmd = new SqlCommand("getallproducerdetailsprocedure", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            conn.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    Producers producer = new Producers();
                    producer.Id = Convert.ToInt32(rdr.GetValue(0).ToString());
                    producer.Name = rdr.GetValue(1).ToString();
                    producer.Sex = (ProducerSex)Enum.Parse(typeof(ProducerSex), rdr.GetValue(2).ToString());
                    producer.DOB = Convert.ToDateTime(rdr.GetValue(3).ToString());
                    producer.Bio = rdr.GetValue(4).ToString();
                    producer.Image = rdr.GetValue(5).ToString();
                    _producers.Add(producer);
                }
            }
            conn.Close();
            return _producers;
        }

        public bool AddProducer(Producers producerdata)
        {

            SqlCommand cmd = new SqlCommand("addproducerprocedure", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter p1 = cmd.Parameters.Add("@ProducerName", SqlDbType.VarChar, 50);
            SqlParameter p2 = cmd.Parameters.Add("@Sex", SqlDbType.VarChar, 50);
            SqlParameter p3 = cmd.Parameters.Add("@DOB", SqlDbType.Date);
            SqlParameter p4 = cmd.Parameters.Add("@Bio", SqlDbType.VarChar, 1000);
            SqlParameter p5 = cmd.Parameters.Add("@ImagePath", SqlDbType.VarChar, 100);

            p1.Value = producerdata.Name;
            p2.Value = producerdata.Sex;
            p3.Value = producerdata.DOB;
            p4.Value = producerdata.Bio;
            p5.Value = producerdata.Image;
            conn.Open();
            int count = cmd.ExecuteNonQuery();
            if (count > 0)
            {
                conn.Close();
                return true;
            }
            else
            {
                conn.Close();
                return false;
            }
        }

    }
}
