﻿using MovieSite.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieSite.Models
{
    public interface IMoviesRepository
    {
        IEnumerable<MovieDetails> MovieDetails(int id);
        IEnumerable<Movies> ListMovies();
        bool Add(AddMovieDetails moviedata);
        Movies Edit(Movies moviechange);
        Movies Delete(int id);
        IEnumerable<Producers> getproducername();

    }
}
