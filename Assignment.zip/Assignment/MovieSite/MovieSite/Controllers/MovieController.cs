﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MovieSite.Models;
using MovieSite.ViewModels;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MovieSite.Controllers
{
    [Route("")]
    public class MovieController : Controller
    {
        // GET: /<controller>/

        private readonly IMoviesRepository _moviesRepository;
        private readonly IHostingEnvironment hostingEnvironment;
        private AddMovieDetails movieobject;
        public MovieController(IMoviesRepository movierepository,IHostingEnvironment hostingEnvironment)
        {
            movieobject = new AddMovieDetails();
            _moviesRepository = movierepository;
            this.hostingEnvironment = hostingEnvironment;
        }

        [HttpGet]
        [Route("")]
        [Route("Movie/Index")]
        public IActionResult Index()
        {
            IEnumerable<Movies> model = _moviesRepository.ListMovies();
            return View(model);
        }

        [HttpGet]
        [Route("Movie/Details/{id}")]
        public IActionResult Details(int id)
        {
            IEnumerable<MovieDetails> model =  _moviesRepository.MovieDetails(id);
            return View(model);     
        }

        [HttpPost]
        [HttpGet]
        [Route("Movie/AddMovie")]
        public IActionResult AddMovie(AddMovie model)
        {
            if (ModelState.IsValid)
            {
                string uniqueFileName = null;
                if (model.Image != null)
                {
                    string folderupload = Path.Combine(hostingEnvironment.WebRootPath, "Images");
                    uniqueFileName = model.Image.FileName;
                    string filepath = Path.Combine(folderupload, uniqueFileName);
                    model.Image.CopyTo(new FileStream(filepath, FileMode.Create));
                }

               
                
                    movieobject.Name= model.Name;
                    movieobject.YearOfRelease = model.YearOfRelease;
                    movieobject.Plot = model.Plot; 
                    movieobject.Image = "~/Images/" + uniqueFileName;
                    // ActorName = model.ActorName,
                    movieobject.ProducerName = model.ProducerName;
                

                   _moviesRepository.Add(movieobject);
                   return RedirectToAction("Index");

        }
            ViewBag.producerdata = _moviesRepository.getproducername();
            return View(model);
        }

       

    }
}
