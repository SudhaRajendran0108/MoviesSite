﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using MovieSite.Models;
using MovieSite.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MovieSite.Controllers
{
    public class ProducerController : Controller
    {
        // GET: /<controller>/

        private IProducersRepository _producersRepository;
        private readonly IHostingEnvironment hostingEnvironment;
        private Producers producerobject;

        public ProducerController(IProducersRepository producerrepository,IHostingEnvironment hostingEnvironment)
        {
            producerobject = new Producers();
            this.hostingEnvironment = hostingEnvironment;
            _producersRepository = producerrepository;
        }

        [Route("Producer/Index")]
        public IActionResult Index()
        {
            
            IEnumerable<Producers> model = _producersRepository.ListProducers();
            return View(model);
        }

        [HttpPost]
        [HttpGet]
        [Route("Movie/AddMovie/Producer/AddProducer")]
        public IActionResult AddProducer(AddProducer model)
        {
            if (ModelState.IsValid)
            {
                string uniqueFileName = null;
                if (model.Image != null)
                {
                    string folderupload = Path.Combine(hostingEnvironment.WebRootPath, "ProducerImages");
                    uniqueFileName = model.Image.FileName;
                    string filepath = Path.Combine(folderupload, uniqueFileName);
                    model.Image.CopyTo(new FileStream(filepath, FileMode.Create));
                }


                producerobject.Name = model.Name;
                producerobject.Sex = model.Sex;
                producerobject.DOB = model.DOB;
                producerobject.Bio = model.Bio;
                producerobject.Image = "~/ProducerImages/" + uniqueFileName;

                _producersRepository.AddProducer(producerobject);
                Response.Redirect("/Movie/AddMovie");
               

            }
          
            return View(model);
        }



    }
}
