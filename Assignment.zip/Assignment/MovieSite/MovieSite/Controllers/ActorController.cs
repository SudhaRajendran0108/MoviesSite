﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MovieSite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieSite.Controllers
{
    
    public class ActorController : Controller
    {
        // GET: /<controller>/

        private IActorsRepository _actorsRepository;

        public ActorController(IActorsRepository actorrepository)
        {
            _actorsRepository = actorrepository;
        }
        
        [Route("Actor/Index")]
        public IActionResult Index()
        {
           
            IEnumerable<Actors> model = _actorsRepository.ListActors();
            return View(model);
        }

       
    }
}
